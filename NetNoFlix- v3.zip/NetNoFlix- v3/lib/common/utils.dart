import 'package:flutter/material.dart';

const imageUrl = 'https://image.tmdb.org/t/p/w500';
const kBackgoundColor = Color(0xff121012);
const kbuttonColor = Color.fromARGB(255, 89, 54, 133);
const apiKey = 'aeb1cb787f869b03b208c80454fc4755';
 const Color backgroundPrimary = Color.fromARGB(255, 171, 169, 180);
