class TvSeriesDetailModel {
  final int id;
  final String name;
  final String overview;
  final double voteAverage;
  final String backdropPath;
  final String posterPath;

  TvSeriesDetailModel({
    required this.id,
    required this.name,
    required this.overview,
    required this.voteAverage,
    required this.backdropPath,
    required this.posterPath,
  });

  factory TvSeriesDetailModel.fromJson(Map<String, dynamic> json) {
    return TvSeriesDetailModel(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      overview: json['overview'] ?? '',
      voteAverage: json['vote_average']?.toDouble() ?? 0.0,
      backdropPath: json['backdrop_path'] ?? '',
      posterPath: json['poster_path'] ?? '',
    );
  }
}
