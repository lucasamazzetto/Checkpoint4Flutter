import 'dart:convert';

class TvSeriesRecommendationsModel {
  int page;
  List<TvSeriesResult> results;
  int totalPages;
  int totalResults;

  TvSeriesRecommendationsModel({
    required this.page,
    required this.results,
    required this.totalPages,
    required this.totalResults,
  });

  TvSeriesRecommendationsModel copyWith({
    int? page,
    List<TvSeriesResult>? results,
    int? totalPages,
    int? totalResults,
  }) =>
      TvSeriesRecommendationsModel(
        page: page ?? this.page,
        results: results ?? this.results,
        totalPages: totalPages ?? this.totalPages,
        totalResults: totalResults ?? this.totalResults,
      );

  factory TvSeriesRecommendationsModel.fromRawJson(String str) =>
      TvSeriesRecommendationsModel.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory TvSeriesRecommendationsModel.fromJson(Map<String, dynamic> json) =>
      TvSeriesRecommendationsModel(
        page: json["page"] ?? 1, // Default to page 1 if not present
        results: List<TvSeriesResult>.from(
          json["results"].map((x) => TvSeriesResult.fromJson(x)),
        ),
        totalPages: json["total_pages"] ?? 1, // Default to 1 if not present
        totalResults: json["total_results"] ?? 0, // Default to 0 if not present
      );

  Map<String, dynamic> toJson() => {
        "page": page,
        "results": List<dynamic>.from(results.map((x) => x.toJson())),
        "total_pages": totalPages,
        "total_results": totalResults,
      };
}

class TvSeriesResult {
  String backdropPath;
  int id;
  String name;
  String overview;
  String posterPath;
  bool adult;
  double popularity;
  double voteAverage;
  int voteCount;
  DateTime firstAirDate;

  TvSeriesResult({
    required this.backdropPath,
    required this.id,
    required this.name,
    required this.overview,
    required this.posterPath,
    required this.adult,
    required this.popularity,
    required this.voteAverage,
    required this.voteCount,
    required this.firstAirDate,
  });

  TvSeriesResult copyWith({
    String? backdropPath,
    int? id,
    String? name,
    String? overview,
    String? posterPath,
    bool? adult,
    double? popularity,
    double? voteAverage,
    int? voteCount,
    DateTime? firstAirDate,
  }) =>
      TvSeriesResult(
        backdropPath: backdropPath ?? this.backdropPath,
        id: id ?? this.id,
        name: name ?? this.name,
        overview: overview ?? this.overview,
        posterPath: posterPath ?? this.posterPath,
        adult: adult ?? this.adult,
        popularity: popularity ?? this.popularity,
        voteAverage: voteAverage ?? this.voteAverage,
        voteCount: voteCount ?? this.voteCount,
        firstAirDate: firstAirDate ?? this.firstAirDate,
      );

  factory TvSeriesResult.fromRawJson(String str) =>
      TvSeriesResult.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory TvSeriesResult.fromJson(Map<String, dynamic> json) => TvSeriesResult(
        backdropPath: json["backdrop_path"] ?? '',
        id: json["id"] ?? 0,
        name: json["name"] ?? '',
        overview: json["overview"] ?? '',
        posterPath: json["poster_path"] ?? '',
        adult: json["adult"] ?? false,
        popularity: (json["popularity"] ?? 0.0).toDouble(),
        voteAverage: (json["vote_average"] ?? 0.0).toDouble(),
        voteCount: json["vote_count"] ?? 0,
        firstAirDate: json["first_air_date"] != null
            ? DateTime.tryParse(json["first_air_date"]) ?? DateTime(1970, 1, 1)
            : DateTime(1970, 1, 1),
      );

  Map<String, dynamic> toJson() => {
        "backdrop_path": backdropPath,
        "id": id,
        "name": name,
        "overview": overview,
        "poster_path": posterPath,
        "adult": adult,
        "popularity": popularity,
        "vote_average": voteAverage,
        "vote_count": voteCount,
        "first_air_date":
            "${firstAirDate.year.toString().padLeft(4, '0')}-${firstAirDate.month.toString().padLeft(2, '0')}-${firstAirDate.day.toString().padLeft(2, '0')}",
      };
}
