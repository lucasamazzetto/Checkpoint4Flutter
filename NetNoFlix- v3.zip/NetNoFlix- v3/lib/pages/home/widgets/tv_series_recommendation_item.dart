import 'package:flutter/material.dart';
import 'package:movie_app/models/tv_series_recommendations_model.dart';

class TvSeriesRecommendationItem extends StatelessWidget {
  final TvSeriesResult recommendation;

  const TvSeriesRecommendationItem({super.key, required this.recommendation});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Column(
        children: [
          Image.network(
            'https://image.tmdb.org/t/p/w200${recommendation.posterPath}',
            width: 100,
            height: 150,
            fit: BoxFit.cover,
          ),
          const SizedBox(height: 5),
          Text(
            recommendation.name,
            style: const TextStyle(fontSize: 14),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}
