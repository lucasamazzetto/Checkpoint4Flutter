import 'package:flutter/material.dart';
import 'package:movie_app/models/tv_series_detail_model.dart';
import 'package:movie_app/models/tv_series_recommendations_model.dart';
import 'package:movie_app/services/api_services.dart';
import 'package:movie_app/pages/home/widgets/tv_series_recommendation_horizontal_list.dart';

class TvSeriesDetailsPage extends StatefulWidget {
  final int seriesId;

  const TvSeriesDetailsPage({super.key, required this.seriesId});

  @override
  State<TvSeriesDetailsPage> createState() => _TvSeriesDetailsPageState();
}

class _TvSeriesDetailsPageState extends State<TvSeriesDetailsPage> {
  final ApiServices apiServices = ApiServices();
  late Future<TvSeriesDetailModel> seriesDetail;
  late Future<TvSeriesRecommendationsModel> seriesRecommendations;

  @override
  void initState() {
    super.initState();
    seriesDetail = apiServices.getTvSeriesDetail(widget.seriesId);
    seriesRecommendations = apiServices.getTvSerieRecommendations(widget.seriesId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        
      ),
      body: FutureBuilder<TvSeriesDetailModel>(
        future: seriesDetail,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Erro: ${snapshot.error}'));
          } else if (snapshot.hasData) {
            final series = snapshot.data!;
            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Image.network(
                    'https://image.tmdb.org/t/p/w500${series.backdropPath}',
                    fit: BoxFit.cover,
                    width: double.infinity,
                    height: 250,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          series.name,
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Avaliação: ${series.voteAverage.toString()}',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          series.overview,
                          style: const TextStyle(fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.0),
                    child: Text(
                      'Recomendações:',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  FutureBuilder<TvSeriesRecommendationsModel>(
  future: seriesRecommendations,
  builder: (context, snapshot) {
    if (snapshot.connectionState == ConnectionState.waiting) {
      return const Center(child: CircularProgressIndicator());
    }
    if (snapshot.hasError) {
      return Center(child: Text('Erro: ${snapshot.error}'));
    }
    if (snapshot.hasData) {
      // Certifique-se de que estamos passando a lista correta de TvSeriesResult
      return TvSeriesRecommendationHorizontalList(
        recommendations: snapshot.data!.results,
      );
    }
    return const Center(child: Text('Nenhuma recomendação encontrada.'));
  },
)

                ],
              ),
            );
          }
          return const Center(child: Text('Detalhes não encontrados.'));
        },
      ),
    );
  }
}
